#ifndef IO_HPP
#define IO_HPP

#include <string>
#include "floresta.hpp"
#include "animal.hpp"

void salvarSaida(const std::string& arquivo, const Floresta& floresta, int interacao);
void lerEntrada(const std::string& arquivo, Floresta& floresta, int& fogoX, int& fogoY, Animal& animal);

#endif
