#include "io.hpp"
#include <fstream>

void lerEntrada(const std::string& arquivo, Floresta& floresta, int& fogoX, int& fogoY, Animal& animal) {
    std::ifstream entrada(arquivo);
    int linhas, colunas;
    entrada >> linhas >> colunas >> fogoX >> fogoY;

    floresta = Floresta(linhas, colunas);
    bool animalPosicionado = false;

    for (int i = 0; i < linhas; ++i) {
        for (int j = 0; j < colunas; ++j) {
            entrada >> floresta.matriz[i][j];
            if (!animalPosicionado && floresta.matriz[i][j] == 0) {
                animal = Animal(i, j);
                animalPosicionado = true;
            }
        }
    }
    entrada.close();
}


void salvarSaida(const std::string& arquivo, const Floresta& floresta, int interacao) {
    std::ofstream saida(arquivo, std::ios::app);
    saida << "Interacao: " << interacao << "\n\n";
    saida << "Matriz atualizada:\n\n";

    for (int i = 0; i < floresta.linhas; ++i) {
        for (int j = 0; j < floresta.colunas; ++j) {
            saida << floresta.matriz[i][j] << " ";
        }
        saida << "\n";
    }

    saida << "\n";
    saida.close();
}
