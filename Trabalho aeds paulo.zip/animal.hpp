#ifndef ANIMAL_HPP
#define ANIMAL_HPP

#include "floresta.hpp"

struct Animal {
    int x, y;
    int passos = 0;
    int encontrouAgua = 0;
    int morreuNaInteracao = -1;

    Animal(int i, int j);
    void mover(const Floresta& floresta);
    bool morreu(const Floresta& floresta) const;
};

#endif
