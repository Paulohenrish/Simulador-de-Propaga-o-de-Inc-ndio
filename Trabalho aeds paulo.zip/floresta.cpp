#include "floresta.hpp"

Floresta::Floresta(int l, int c) : linhas(l), colunas(c), matriz(l, std::vector<int>(c)) {}

bool Floresta::haFogo() const {
    for (int i = 0; i < linhas; ++i) {
        for (int j = 0; j < colunas; ++j) {
            if (matriz[i][j] == 2) 
                return true;
        }
    }
    return false;
}
