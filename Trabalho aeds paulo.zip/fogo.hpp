#ifndef FOGO_HPP
#define FOGO_HPP

#include "floresta.hpp"

class Fogo {
public:
    void propagar(Floresta& floresta);
};

#endif
