#include "fogo.hpp"
#include <vector>

void Fogo::propagar(Floresta& floresta) {
    std::vector<std::pair<int, int>> novos;

    for (int i = 0; i < floresta.linhas; ++i) {
        for (int j = 0; j < floresta.colunas; ++j) {
            if (floresta.matriz[i][j] == 2) {
                static const std::vector<std::pair<int, int>> direcoes = {
                    {-1, 0}, {1, 0}, {0, -1}, {0, 1}
                };

                for (auto [dx, dy] : direcoes) {
                    int ni = i + dx;
                    int nj = j + dy;

                    if (ni >= 0 && nj >= 0 && ni < floresta.linhas && nj < floresta.colunas) {
                        int celula = floresta.matriz[ni][nj];
                        if (celula == 0 || celula == 1) {
                            novos.push_back({ni, nj});
                        }
                    }
                }

                floresta.matriz[i][j] = 3;
            }
        }
    }

    for (auto [i, j] : novos) {
        floresta.matriz[i][j] = 2;
    }
}
