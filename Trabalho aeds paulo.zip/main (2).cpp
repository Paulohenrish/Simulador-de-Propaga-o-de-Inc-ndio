#include "floresta.hpp"
#include "animal.hpp"
#include "fogo.hpp"
#include "io.hpp"
#include <iostream>
#include <fstream>

int main() {
    Floresta floresta(0, 0);
    int fogoX, fogoY;
    Animal animal(0, 0);

    std::ofstream limpar("output.dat", std::ios::trunc);
    limpar.close();
    std::ofstream limparDebug("output_debug.txt", std::ios::trunc);
    limparDebug.close();

lerEntrada("input.dat", floresta, fogoX, fogoY, animal);

floresta.matriz[fogoX][fogoY] = 2;

Fogo fogo;
int i = 1;

while (floresta.haFogo()) {
    salvarSaida("output.dat", floresta, i);

    std::ofstream debug("output_debug.txt", std::ios::app);
    debug << "Iteracao " << i << "\n";
    for (int l = 0; l < floresta.linhas; ++l) {
        for (int c = 0; c < floresta.colunas; ++c) {
            if (l == animal.x && c == animal.y)
                debug << 'A';
            else
                debug << floresta.matriz[l][c];
        }
        debug << "\n";
    }
    debug << "\n";
    debug.close();

    animal.mover(floresta);
    fogo.propagar(floresta);

    if (animal.morreu(floresta)) {
        animal.morreuNaInteracao = i;
        break;
    }

    i++;
}

    std::ofstream relatorio("output.dat", std::ios::app);
    relatorio << "Animal percorreu " << animal.passos << " passos e encontrou água " << animal.encontrouAgua << " vezes.\n";
    if (animal.morreuNaInteracao != -1)
        relatorio << "Animal morreu na interação " << animal.morreuNaInteracao << ".\n";
    else
        relatorio << "Animal sobreviveu.\n";
    relatorio.close();

    std::cout << "Simulação concluída. Veja output.dat e output_debug.txt.\n";

    return 0;
}
