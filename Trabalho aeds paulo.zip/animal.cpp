#include "animal.hpp"
#include <vector>

Animal::Animal(int i, int j) : x(i), y(j) {}

void Animal::mover(const Floresta& floresta) {
    static const std::vector<std::pair<int, int>> direcoes = {
        {-1, 0}, {1, 0}, {0, -1}, {0, 1}
    };

    for (auto [dx, dy] : direcoes) {
        int nx = x + dx;
        int ny = y + dy;

        if (nx >= 0 && ny >= 0 && nx < floresta.linhas && ny < floresta.colunas) {
            if (floresta.matriz[nx][ny] == 0 || floresta.matriz[nx][ny] == 4) {
                x = nx;
                y = ny;
                passos++;
                if (floresta.matriz[nx][ny] == 4)
                    encontrouAgua++;
                break;
            }
        }
    }
}

bool Animal::morreu(const Floresta& floresta) const {
    return floresta.matriz[x][y] == 2 || floresta.matriz[x][y] == 3;
}
