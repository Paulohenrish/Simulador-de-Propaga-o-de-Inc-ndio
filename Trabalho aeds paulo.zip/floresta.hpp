#ifndef FLORESTA_HPP
#define FLORESTA_HPP

#include <vector>

struct Floresta {
    int linhas, colunas;
    std::vector<std::vector<int>> matriz;

    Floresta(int l, int c);
    bool haFogo() const;
};

#endif
